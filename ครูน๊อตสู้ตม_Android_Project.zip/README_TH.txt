ครูน๊อตสู้ต.ม. — Android Project
โปรเจกต์นี้เป็นแอป Android แบบออฟไลน์สำหรับฝึกตอบคำถาม ตม. เกาหลี
ชื่อแอป: ครูน๊อตสู้ต.ม.
เวอร์ชัน: 1.0

การสร้าง APK:
1. เปิดโฟลเดอร์นี้ด้วย Android Studio
2. รอ Gradle Sync
3. เลือก Build > Build APK(s)
4. APK จะอยู่ใน app/build/outputs/apk/debug/

ตัวเกมใช้ไฟล์ app/src/main/assets/index.html จึงสามารถแก้คำถาม/ข้อมูลได้ภายหลัง
